package com.ram;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="product_seller")
public class ProductSeller {
	@Id
	@Column(name="rid")
	private String prid;
	
	@Column(name="prname")
	private String prname;
	
	@Column(name="mfname")
	private String mfname;
	@Column(name="mdate")
	private String mdate;
	@Column(name="edate")
	private String edate;
	@Column(name="quantity")
	private int quantity;
	@Column(name="price")
	private int price;
	
	public String getPrname() {
		return prname;
	}
	public void setPrname(String prname) {
		this.prname = prname;
	}
	public String getPrid() {
		return prid;
	}
	public void setPrid(String prid) {
		this.prid = prid;
	}
	public String getMfname() {
		return mfname;
	}
	public void setMfname(String mfname) {
		this.mfname = mfname;
	}
	public String getMdate() {
		return mdate;
	}
	public void setMdate(String mdate) {
		this.mdate = mdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
	
}
