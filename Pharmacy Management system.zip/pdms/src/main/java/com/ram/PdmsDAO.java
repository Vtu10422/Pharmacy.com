package com.ram;

import org.springframework.data.repository.CrudRepository;

public interface PdmsDAO extends CrudRepository<Customer, String> {

}
