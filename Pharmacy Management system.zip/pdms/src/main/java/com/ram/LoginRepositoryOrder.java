package com.ram;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginRepositoryOrder  extends JpaRepository<Order,String>{

}
