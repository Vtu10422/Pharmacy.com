package com.ram;

import org.springframework.data.repository.CrudRepository;

public interface PdmsDAO1 extends CrudRepository<Seller, String> {

}
