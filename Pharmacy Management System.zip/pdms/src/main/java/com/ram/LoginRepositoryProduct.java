package com.ram;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginRepositoryProduct extends JpaRepository<ProductSeller,String> {

}
